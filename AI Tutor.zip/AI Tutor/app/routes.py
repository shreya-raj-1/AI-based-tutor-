from flask import Blueprint, render_template, request, jsonify
from app.bot_logic import fetch_from_wikipedia, play_on_youtube, search_new_tab, fetch_definition

main = Blueprint('main', __name__)

@main.route('/')
def home():
    return render_template('home.html')

@main.route('/api/chat', methods=['POST'])
def chat():
    user_input = request.json.get('message')
    if not user_input:
        response = "Sorry, I didn't understand that. Please type a valid query."
        return jsonify({"response": response})

    user_input = user_input.lower().strip()

    if user_input.startswith("what is") or user_input.startswith("tell"):
        query = user_input.replace("what is", "").replace("tell", "").strip()
        if query:
            response = fetch_from_wikipedia(query)
        else:
            response = "Please provide more details after 'what is' or 'tell'."

    elif user_input.startswith("search"):
        query = user_input.replace("search", "").strip()
        if query:
            response = search_new_tab(query)
        else:
            response = "Please specify what you want to search for."

    elif user_input.startswith("play"):
        query = user_input.replace("play", "").strip()
        if query:
            response = play_on_youtube(query)
        else:
            response = "Please specify what you want to play."

    elif user_input.startswith("define"):
        word = user_input.replace("define", "").strip()
        if word:
            response = fetch_definition(word)
        else:
            response = "Please provide a word to define."

    else:
        response = (
            "Sorry, I didn't understand that. Try 'search <topic>', 'play <video>', or 'what is <topic>'."
        )

    return jsonify({"response": response})
