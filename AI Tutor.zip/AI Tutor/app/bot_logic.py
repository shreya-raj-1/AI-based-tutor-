import wikipedia
import pywhatkit as kit
from PyMultiDictionary import MultiDictionary

dictionary = MultiDictionary()

def fetch_from_wikipedia(query):
    try:
        result = wikipedia.summary(query, sentences=3)
        return result
    except wikipedia.exceptions.DisambiguationError as e:
        return f"Ambiguous query. Try being more specific. Suggestions: {e.options}"
    except wikipedia.exceptions.PageError:
        return "Couldn't find any information on that topic."
    except Exception as e:
        return f"An error occurred: {e}"

def play_on_youtube(search_query):
    try:
        kit.playonyt(search_query)
        return f"Playing {search_query} on YouTube..."
    except Exception as e:
        return f"An error occurred while trying to play the video: {e}"

def search_new_tab(search_query):
    try:
        kit.search(search_query)
        return f"Opening search results for '{search_query}' in a new tab..."
    except Exception as e:
        return f"Error while trying to search: {e}"

def fetch_definition(word):
    try:
        definition = dictionary.meaning(word)
        if definition:
            formatted_definitions = []
            for word_type, meanings in definition.items():
                formatted_definitions.append(f"{word_type}: {', '.join(meanings[:3])}")  # Limit to 3 meanings
            return f"Definition of {word}:\n" + "\n".join(formatted_definitions)
        else:
            return f"Sorry, I couldn't find the definition of '{word}'."
    except Exception as e:
        return f"An error occurred: {e}"
